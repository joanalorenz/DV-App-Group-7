
######################################## SERVER  ########################################################################################


server <- function(input, output) {
  
  ##################### REACTIVE VARIABLES ################################################################################################  
  # Create reactive variables for interactive widgets input  
  numOfStation <- reactive({df.station[sample(nrow(df.station),input$numberInput[1]), ] })
  
  nearStation <- reactive({
    df.station %>%
      filter(df.station$name == input$stationInputC)
  })
  
  startStation <- reactive({
    df.station %>%
      filter(df.station$name == input$stationInputA)
  })
  
  stopStation <- reactive({
    df.station %>%
      filter(df.station$name == input$stationInputB)
  })
  
  dist <- reactive({
    paste(toString(floor(hav.dist( startStation()$long, startStation()$lat, stopStation()$long, stopStation()$lat))), " meters")
  })
  
  tripStaton <- reactive({
    selLat1 = startStation()$lat
    selLong1 = startStation()$long
    selLat2 = stopStation()$lat
    selLong2 = stopStation()$long
    selLat3 = nearStation()$lat
    selLong3 = nearStation()$long
    for (i in 1:58) {
      df.station$dist[i] = hav.dist(selLong3, selLat3, df.station$long[i], df.station$lat[i])
    } 
    df.station %>%
      filter(df.station$dist <= input$distInput)
    
  })
  
  selected <- reactive({
    if (toString(input$proximity)=="Select a station") {
      return(2)
    } else {
      return(3)
    }
  })
  
  from_to <- reactive({
    if (toString(input$station)=="Start Station") {
      return(TRUE)
    } else {
      return(FALSE)
    }
  })
  
  date <- reactive({input$date})
  
  # Filter dataset by time of day user input
  trips <- reactive({
    if (input$station == "Start Station") {
      if (toString(input$daytime) == "Morning (6 a.m. - 11 a.m.)") 
      {return(df.trip[df.trip$start_daytime == "Morning", ])}
      else if (toString(input$daytime) == "Midday (11 a.m. - 5 p.m.)") 
      {return(df.trip[df.trip$start_daytime == "Afternoon", ])}
      else if (toString(input$daytime) == "Evening (5 p.m.- 10 p.m.)")
      {return(df.trip[df.trip$start_daytime == "Evening", ])}
      else if (toString(input$daytime) == "Night (10 p.m. - 4 a.m.)")
      {return(df.trip[df.trip$start_daytime == "Night", ])}
      else 
      {return(df.trip)}}
    else {
      if (toString(input$daytime) == "Morning (6 a.m. - 11 a.m.)") 
      {return(df.trip[df.trip$stop_daytime == "Morning", ])}
      else if (toString(input$daytime) == "Midday (11 a.m. - 5 p.m.)") 
      {return(df.trip[df.trip$stop_daytime == "Afternoon", ])}
      else if (toString(input$daytime) == "Evening (5 p.m.- 10 p.m.)")
      {return(df.trip[df.trip$stop_daytime == "Evening", ])}
      else if (toString(input$daytime) == "Night (10 p.m. - 4 a.m.)")
      {return(df.trip[df.trip$stop_daytime == "Night", ])}
      else 
      {return(df.trip)}}
    
  })
  
  # Filter data frame based on station and day input 
  filtered <- reactive({
    if (toString(input$specificday) == 'FALSE') {
      
      if (toString(input$station) == 'Start Station') {
        
        
        if (input$Day == "All Days"){
          
          var <- length(unique(trips()$starttime))
          
          trips() %>%
            filter()%>%
            group_by(from_station_id) %>%
            summarize(n_trips = n()/var) %>%
            left_join(df.station, by = c("from_station_id" = "station_id"))%>%
            mutate(example =  paste(name, as.integer(n_trips), sep = ", average number of trips: "))
        }
        
        else if (input$Day == "Weekend"){
          
          
          tempdf <- trips()
          
          tempdf <- tempdf[tempdf$starttime_weekend == "Weekend", ]
          
          var <- length(unique(tempdf$starttime))
          
          trips() %>%
            filter(trips()$starttime_weekend == "Weekend") %>%
            group_by(from_station_id) %>%
            summarize(n_trips = n()/var) %>%
            left_join(df.station, by = c("from_station_id" = "station_id"))%>%
            mutate(example =  paste(name, as.integer(n_trips), sep = ", average number of trips: "))
        }
        else if (input$Day == "Weekday"){
          
          
          tempdf <- trips()
          
          tempdf <- tempdf[tempdf$starttime_weekend == "Weekday", ]
          
          var <- length(unique(tempdf$starttime))
          
          trips() %>%
            filter(trips()$starttime_weekend == "Weekday") %>%
            group_by(from_station_id) %>%
            summarize(n_trips = n()/var) %>%
            left_join(df.station, by = c("from_station_id" = "station_id"))%>%
            mutate(example =  paste(name, as.integer(n_trips), sep = ",  Average number of trips: "))          }
      }
      
      else {
        
        
        if (input$Day == "All Days"){
          
          var <- length(unique(trips()$starttime))
          
          trips() %>%
            filter()%>%
            group_by(to_station_id) %>%
            summarize(n_trips = n()/var) %>% 
            left_join(df.station, by = c("to_station_id" = "station_id"))%>%
            mutate(example =  paste(name, as.integer(n_trips), sep = ", average number of trips: ")) 
        }
        
        else if (input$Day == "Weekend"){
          
          
          tempdf <- trips()
          
          tempdf <- tempdf[tempdf$starttime_weekend == "Weekend", ]
          
          var <- length(unique(tempdf$starttime))
          
          trips() %>%
            filter(trips()$starttime_weekend == "Weekend") %>%
            group_by(to_station_id) %>%
            summarize(n_trips = n()/var) %>% 
            left_join(df.station, by = c("to_station_id" = "station_id"))%>%
            mutate(example =  paste(name, as.integer(n_trips), sep = ", average number of trips: "))
        }
        else if (input$Day == "Weekday"){
          
          
          tempdf <- trips()
          
          tempdf <- tempdf[tempdf$starttime_weekend == "Weekday", ]
          
          var <- length(unique(tempdf$starttime))
          
          trips() %>%
            filter(trips()$starttime_weekend == "Weekday") %>%
            group_by(to_station_id) %>%
            summarize(n_trips = n()/var) %>% 
            left_join(df.station, by = c("to_station_id" = "station_id"))%>%
            mutate(example =  paste(name, as.integer(n_trips), sep = ", average number of trips: "))
        }
      }
    }
    # Filter based on Start/End Station selection
    else {
      if (from_to() == TRUE) {
        trips() %>%
          filter(format(trips()$starttime,"%Y-%m-%d") == date()) %>%
          group_by(from_station_id) %>%
          summarize(n_trips = n()) %>% 
          left_join(df.station, by = c("from_station_id" = "station_id"))%>%
          mutate(example =  paste(name, as.integer(n_trips), sep = ", Number of trips: "))
      }
      else {
        trips() %>% 
          filter(format(trips()$stoptime,"%Y-%m-%d") == date()) %>%
          group_by(to_station_id) %>%
          summarize(n_trips = n()) %>% 
          left_join(df.station, by = c("to_station_id" = "station_id"))%>%
          mutate(example =  paste(name, as.integer(n_trips), sep = ", Number of trips: "))
      }
    }
    
  })
  
  # Filter to top 5 stations based on user input
  tmp.df <- reactive ({
    if (toString(input$top5) == 'TRUE') 
    {filtered() %>%
        arrange(desc(n_trips)) %>%
        head(5)}
    else {filtered()}
  })
  
  top5 <- reactive ({
    
    filtered() %>%
      arrange(desc(n_trips)) %>%
      head(5)
    
  })
  
  # Filter by rain or sun based on user input 
  weather_trips <- reactive({
    if (toString(input$rain) == "Sunny days")
    {trips_day %>%
        filter( Rain %in% c(0))}
    else{
      trips_day %>%
        filter( Rain %in% c(1))
    }
  })
  
  # Filter by selected gender and months
  some.df <- reactive({
    if (toString(input$gender) == 'FALSE') {
      df.trip
    } else {
      if (input$filter_boxplot == 'All' ) {
        df.trip
      } else {
        df.trip %>%
          filter(df.trip$gender == input$filter_boxplot)
      }
      
    }
  })
  
  # Filter by age and selected gender
  some.df2 <- reactive({
    if (toString(input$gender) == 'FALSE'){
      df.trip %>%
        filter(df.trip$age<100)
    } else {
      if (input$filter_boxplot == 'All' ) {
        df.trip %>%
          filter(df.trip$age<100)
      } else {
        
        df.trip %>%
          filter(
            #df.trip$age.group3 == input$agefilter,
            df.trip$age<100, df.trip$gender == input$filter_boxplot)
      }
    }
  })
  
  # Side-by-side bar chart in Customer Analysis
  some.df3 <- df.trip %>%
    filter(
      df.trip$Year == '2015',
      df.trip$gender == 'Male'| df.trip$gender =='Female')
  
  some.df3$Month_trip_factor <- factor(some.df3$Month_trip, levels = c('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'))
  
  # filter by start and end date user input
  start_date <- reactive({input$str_date})
  stop_date <- reactive({input$stp_date})
  
  ################################ OUTPUT TO HOMEPAGE ################################################################################  
  # create map based on user choice in stations tab
  output$firstExample <- renderLeaflet({
    
    # Distance between two stations  
    if (selected() == 3) {
      leaflet(tripStaton()) %>% 
        addTiles(group="OSM") %>%
        addProviderTiles(providers$Stamen.TonerLite) %>%
        setView(
          lng=-122.335167,
          lat=47.619113,
          zoom=12.46
        ) %>%
        addMarkers(startStation()$long, startStation()$lat, label=~startStation()$name) %>%
        addMarkers(stopStation()$long, stopStation()$lat,label=~stopStation()$name) %>%
        addPolylines(lng = c(startStation()$long, stopStation()$long), lat = c(startStation()$lat, stopStation()$lat), layerId = NULL, color = "#03F", weight = 5, opacity = 0.5, fill = FALSE, fillColor = "#03F",
                     fillOpacity = 0.2, label = dist())
      # Stations within user-given radius  
    } else if (selected() == 2) {
      leaflet(tripStaton()) %>%
        addTiles(group="OSM") %>%
        addProviderTiles(providers$Stamen.TonerLite) %>%
        setView(
          lng=-122.335167,
          lat=47.619113,
          zoom=12.46
        ) %>%
        addMarkers(~long, ~lat, popup=~htmlEscape(name)) %>%
        addMouseCoordinates(style = "basic")
    } 
  })
  
  # Create variable based on user click on map in order to calculate distance to stations
  observeEvent(input$firstExample_click, {
    click <- input$firstExample_click
    clat <- click$lat
    clng <- click$lng
    
    # find nearest station
    for (i in 1:58) {
      df.station$dist_nearest[i] = hav.dist(clng, clat, df.station$long[i], df.station$lat[i])
    }
    
    top <- df.station %>%
      arrange(desc(dist_nearest)) %>%
      tail(1)
    
    # Starting point and nearest station
    leafletProxy('firstExample') %>%
      clearShapes() %>%
      clearMarkers() %>%
      addCircles(lng=clng, lat=clat, group='circles',label = "Starting Point",
                 weight=1, radius=100, color='black', fillColor='green',
                 fillOpacity=0.2, opacity=1, layerId = 2) %>%
      addMarkers(lng=top$long, lat=top$lat, label = top$name )
    
    
  })
  # Clearing the map 
  observeEvent(input$button, {
    leafletProxy('firstExample') %>%
      clearShapes() %>%
      clearMarkers()
  })
  
  
  ######################## OUTPUT TO TRIP TABSET ################################################################################  
  
  # Create trips map output
  output$secondExample <- renderLeaflet({
    
    # Create map with circle markers
    leaflet(tmp.df()) %>%
      addTiles(group="OSM") %>%
      addProviderTiles(providers$Stamen.TonerLite) %>%
      setView(
        lng=-122.335167,
        lat=47.619113,
        zoom=12.46
      )%>%
      addCircleMarkers(lng = ~long, lat = ~lat, weight = 1,label=~example,
                       radius = ~log(n_trips)*10)%>%
      addCircleMarkers(lng = ~long, lat = ~lat, weight = 1, radius = 2,5,fillOpacity = 4)
    
  })
  
  # Create table of top 5 stations to show in the trips tab
  output$table <- renderTable(top5()%>%
                                select(name, n_trips)%>%
                                mutate(n_trips = as.integer(n_trips))%>%
                                rename(Station = name)%>%
                                rename(Trips = n_trips), spacing = "xs")
  
  
  
  
  ####################  OUTPUT TO CUSTOMER ANALYSIS TAB ################################################################################
  # Side-by-side bar plot
  output$bar5 <- renderPlot({
    par(bg=rgb(0.8,0.8,1,0.5) )
    barplot(table(some.df3$gender, some.df3$Month_trip_factor),
            main="Number of trips per month",
            ylab="Trips",
            border="white",
            col=c("#30D5C8","#7A0B7C"),
            col.main="white",
            font.main=2
            ,beside=TRUE,
            cex.names = 1.5,
            col.axis = "white",
            col.lab = "white",
            cex.lab = 1.6,
            cex.main=2,
            font.axis=1.3,
            cex.axis=1.3
            
    )
    legend("topright",
           c("Male","Female"),
           fill = c("#30D5C8","#7A0B7C")
    )
  })
  
  #Pie chart
  colors = c('#12788D', '#01FFFF', '#939496', '#CD4B93')
  
  output$pie <- renderPlot({
    par(bg=rgb(0.8,0.8,1,0.5) )
    pie(table(some.df2()$age.group3), col=colors,
        main="Age of bike customers", col.main="white", font.main=2, cex.main=2, radius=1.09, cex=1.5, labels = NA)
    
    legend("topleft", text.col = 'white', bg='#272B31', box.col='white', text.width = 1.5, box.lwd = 3, legend=c('> 60 yrs', '18-25 yrs', '25-40 yrs', '40-60 yrs'),
           fill= c('#12788D', '#01FFFF', '#939496', '#CD4B93'))
    
  })
  
  #Box plot
  output$box2 <- renderPlot({
    par(bg=rgb(0.8,0.8,1,0.5) )
    boxplot(some.df()$tripduration ~ some.df()$Month_trip_factor, ylim=c(0,3000),  col.axis = "white",
            col.lab = "white",
            cex.lab = 1.6, outline = FALSE, cex.names = 1.5, font.main=2, cex.main=2, cex.axis=1.5, col.main = "white", ylab='Trip dutation [min]',
            border = rgb(205/255,205/255,205/255,0.2), col=rgb(48/255,213/255,200/255,1), medcol="black", main="Trip duration by month")
  })
  
  ####################  OUTPUT TO TRIP ANALYSIS TAB ################################################################################
  
  # time-series graph
  output$box <- renderDygraph({  
    library(xts)          # To make the convertion data-frame / xts format
    library(data.table)
    
    #df.sum_trip <- read.csv("dane/sum_trip_ts2.csv", header=TRUE, sep=";")
    #df.sum_trip$v <-  as.Date(df.sum_trip$v, format = "%d.%m.%Y")
    
    data <- sum_trips
    data <- xts(x=data$minutes, order.by=data$yearandweek)
    dygraph(data) %>%
      dyOptions( drawPoints = TRUE, pointSize = 4, fillGraph=TRUE, drawGrid = FALSE, gridLineColor = NULL, pointShape = "star", 
                 axisTickSize = 4, axisLineColor = "grey",
                 axisLineWidth = 2, axisLabelColor = "lightgrey", axisLabelFontSize = 13,
                 axisLabelWidth = 60, strokeWidth = 2, drawXAxis = TRUE) %>%
      dyRangeSelector(dateWindow = c(start_date(), stop_date())) %>%
      dyUnzoom() %>%
      dyCrosshair(direction = "both")%>%
      dySeries("V1", label = "Total Minutes: ")%>%
      dyLegend(show = "follow")
    
  })
  
  # Weather condition scatter plot
  output$plot <- renderPlot({
    ggplot(weather_trips(), aes(x=Mean_Temperature_F, y=count )) + geom_point(color="#30D5C8", size = 3)  + 
      geom_rug(color="grey")+ labs( x= 'Mean Temperature in Fahrenheit', y= "Number of trips")+
      theme_black()+
      theme(plot.background = element_rect(color= "#272B31",fill = "#272B31"),
            panel.border = element_rect(color = "#272B31"),
            panel.background = element_rect(fill = '#272B31'),
            panel.grid.major = element_line(colour = "#272B31", size=1.5),
            panel.grid.minor = element_line(colour = "#272B31", 
                                            size=.25, 
                                            linetype = "dashed"),
            axis.line.x = element_line(colour = "#272B31", 
                                       size=1.5, 
                                       lineend = "butt"),
            axis.line.y = element_line(colour = "#272B31", 
                                       size=1.5),
            axis.text.x = element_text(colour = "lightgrey", face = "bold", size = 13),
            axis.text.y = element_text(colour = "lightgrey", face = "bold", size = 13),
            axis.title.x = element_text(size=16, face="bold.italic",colour = "lightgrey"),
            axis.title.y = element_text(size=16, face="bold.italic",colour = "lightgrey")
            
      ) + if(toString(input$regression) == 'TRUE'){geom_smooth(method='lm')} 
  })
  
  
  
  ######################## OUTPUT TO DATA TABLE TABS ##########################################################################  
  
  # Output to Trip Data
  output$mytable1 = renderDataTable({
    tmp.df()
  }, options = list(aLengthMenu = c(5, 10, 15), iDisplayLength = 8))
  
  # Output to Weather Data  
  output$mytable2 = renderDataTable({
    df.weather
  }, options = list(aLengthMenu = c(5, 10, 15), iDisplayLength = 8))
  
}
