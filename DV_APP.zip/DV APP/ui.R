
######################################## UI  ######################################################################################################

# Create UI and interactive widgets
ui <- navbarPage(title =  "Capital Bikeshare - Seattle", position = "fixed-top",  footer = tags$h5(br(),br(),br(),br(),br(),'Application created by Group7 Studio'), collapsible = TRUE, fluid = TRUE,
                 theme = shinytheme("slate"),
                 # Customer Tab
                 tabPanel("Customer",
                          fluidPage(br(), br(),br(),
                                    titlePanel("Station Analysis"),
                                    sidebarLayout(
                                      sidebarPanel(
                                        
                                        radioButtons("stat_choice", "What do you want to check",
                                                     choices = c("Proximity", "Distance"),
                                                     selected = "Proximity"),
                                        conditionalPanel(
                                          condition = "input.stat_choice == 'Proximity'",
                                          radioButtons("proximity", "Select", choices= c("Select a point on the map", "Select a station"), selected = "map"
                                          ),   
                                          conditionalPanel(
                                            condition = "input.proximity == 'Select a point on the map'",
                                            h5('Click on the map to show the nearest station to your current location')
                                          ),
                                          conditionalPanel(
                                            condition = "input.proximity == 'Select a station'",
                                            selectInput("stationInputC", "Select Start Station",
                                                        choices = unique(df.station$name)
                                            ),
                                            sliderInput("distInput", "Stations within Distance", min = 10, max = 5000,
                                                        value = c(200), pre = "M ")
                                          )),
                                        conditionalPanel(
                                          condition = "input.stat_choice == 'Distance'",
                                          selectInput("stationInputA", "Select Start Station",
                                                      choices = unique(df.station$name)
                                          ),
                                          
                                          selectInput("stationInputB", "Select End Station",
                                                      choices = unique(df.station$name)
                                          )
                                        ),
                                        # conditionalPanel(
                                        #   condition = "input.stat_choice == 'Near station'",
                                        #   selectInput("stationInputC", "Select Start Station",
                                        #               choices = unique(df.station$name)
                                        #   ),
                                        #   sliderInput("distInput", "Stations within Distance", min = 10, max = 5000,
                                        #               value = c(200), pre = "M ")
                                        # ),
                                        actionButton("button", "Clear Map"),
                                        br()),
                                      
                                      
                                      
                                      mainPanel(
                                        leafletOutput("firstExample", height=700)))
                          )
                 ),
                 # Company Tab
                 navbarMenu("Company",
                            tabPanel("Trip Analysis",br(), br(),br(), 
                                     sidebarLayout(position = "right",
                                                   sidebarPanel(
                                                     
                                                     conditionalPanel(
                                                       condition = "input.specificday == false",
                                                       
                                                       radioButtons("Day",
                                                                    label = "Select between days:",
                                                                    choices = c("All Days","Weekday", "Weekend"),
                                                                    selected = "All Days")
                                                     ),
                                                     
                                                     checkboxInput("specificday", "Select a specific Date"),
                                                     
                                                     conditionalPanel(
                                                       condition = "input.specificday != false",
                                                       
                                                       dateInput("date", "Choose a date:", value = format(first,"%Y-%m-%d")
                                                                 , min = format(first,"%Y-%m-%d"), max= format(last,"%Y-%m-%d")
                                                                 ,format = "yyyy-mm-dd", startview="month"
                                                       )
                                                       
                                                       
                                                       
                                                     ),
                                                     radioButtons("station", "Direction",
                                                                  choices = c("Start Station", "End Station"),
                                                                  selected = "Start Station",inline = TRUE),
                                                     
                                                     selectInput("daytime","Time of Day",choices=c("All Day","Morning (6 a.m. - 11 a.m.)","Midday (11 a.m. - 5 p.m.)","Evening (5 p.m.- 10 p.m.)", "Night (10 p.m. - 4 a.m.)"),selected="All Day")
                                                     ,
                                                     h5("Top 5 most frequented stations")
                                                     ,
                                                     tableOutput('table')
                                                     ,
                                                     checkboxInput("top5", "Show on map")
                                                   )
                                                   ,
                                                   
                                                   mainPanel(
                                                     leafletOutput("secondExample", height=700)
                                                   )
                                     )),
                            "----",
                            # Trip Analysis Tab
                            tabPanel("Trip Stats",br(), br(),br(),
                                     h3("Timeseries analysis of number of Trips",align = "center")
                                     ,dygraphOutput("box"),br(),br(),h3("Influence of Weather on Number of Trips",align = "center"),br(),
                                     fluidRow(
                                       
                                       column(9,                                              
                                              plotOutput("plot")
                                       ),
                                       column(3,
                                              
                                              radioButtons("rain", "What kind of days do you want to inspect?",
                                                           choices = c("Rainy days", "Sunny days"),
                                                           selected = "Sunny days",inline = TRUE),
                                              checkboxInput("regression", "Show regression line")
                                       )
                                       
                                       
                                       
                                     )
                            ),
                            "----",
                            # Customer Analysis Tab
                            tabPanel("Customer Analysis",
                                     fluidPage(br(), br(),br(),
                                               fluidRow(
                                                 
                                                 column(12, wellPanel(plotOutput("bar5"))
                                                 )),
                                               fluidRow(
                                                 column(12, wellPanel(
                                                   checkboxInput("gender", "More details!")
                                                 ))
                                               ), conditionalPanel(
                                                 condition = "input.gender == true",
                                                 radioButtons("filter_boxplot", "What do you want to check",
                                                              choices = c("All","Male", "Female")), plotOutput("box2"), plotOutput("pie")
                                               ))) 
                 ),
                 # Data Tabs
                 navbarMenu("Data",
                            tabPanel("Trips Data",br(), br(),br(), dataTableOutput("mytable1")),
                            "----",
                            tabPanel("Weather Data",br(), br(),br(), dataTableOutput("mytable2"))
                 )
                 
                 
)
