############## LIBRARIES ######################################################################################################################
require(shiny)
require(leaflet)
require(htmltools)
require(ggplot2)
library(shinythemes)
library(shinydashboard)
require(dplyr)
library("magrittr")
library(dygraphs)
library(mapview)
library(gridExtra)


############## GLOBAL VARIABLES ################################################################################################################
# Import CSV's and assign to data frames 
df.station <- read.csv("data/station.csv", header=TRUE, sep=",")
df.trip <- read.csv("data/trip.csv", header=TRUE, sep=",")
df.weather <- read.csv("data/weather.csv", header=TRUE, sep=",")

# Create differing datetime columns for the upcoming analyses
df.trip$starttime_hours <-  as.numeric(format(strptime(df.trip$starttime, "%m/%d/%Y %H:%M"), "%H"))
df.trip$stoptime_hours <-  as.numeric(format(strptime(df.trip$stoptime, "%m/%d/%Y %H:%M"), "%H"))

df.trip$start_daytime <- ifelse(df.trip$starttime_hours >= 4 & df.trip$starttime_hours < 11,"Morning",
                                ifelse(df.trip$starttime_hours >= 11 & df.trip$starttime_hours < 17, "Afternoon",
                                       ifelse(df.trip$starttime_hours >= 17 & df.trip$starttime_hours < 22, "Evening", "Night")))


df.trip$stop_daytime <- ifelse(df.trip$stoptime_hours >= 4 & df.trip$stoptime_hours < 11,"Morning",
                               ifelse(df.trip$stoptime_hours >= 11 & df.trip$stoptime_hours < 17, "Afternoon",
                                      ifelse(df.trip$stoptime_hours >= 17 & df.trip$stoptime_hours < 22, "Evening", "Night")))

df.trip$starttime <-  as.Date(df.trip$starttime, format = "%m/%d/%Y")
df.trip$stoptime <- as.Date(df.trip$stoptime, format = "%m/%d/%Y")

df.trip$starttime_weekend <- ifelse(is.element(weekdays(df.trip$starttime, abbreviate = FALSE), c("Saturday","Sunday")), "Weekend", "Weekday")
df.trip$stoptime_weekend <- ifelse(is.element(weekdays(df.trip$stoptime, abbreviate = FALSE), c("Saturday","Sunday")), "Weekend", "Weekday")
df.weather$Date <- as.Date(df.weather$Date, format = "%m/%d/%Y")

df.trip$Month_trip_factor <- factor(df.trip$Month_trip, levels = c('January', 'February', 'March', 'April'
                                                                   , 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'))

# Sum trip duration by week for Trip Analysis
df.trip$yearandweek <- cut(df.trip$starttime, "week")

sum_trips <- aggregate(tripduration ~ yearandweek, df.trip, sum)
sum_trips$minutes <- sum_trips$tripduration/60
sum_trips$yearandweek <-  as.Date(sum_trips$yearandweek, format = "%Y-%m-%d")




# Calculate trips per day and add weather conditions
trips_day <- df.trip %>%
  group_by(starttime) %>%
  summarize(count=n())%>%
  left_join(df.weather, by = c("starttime" = "Date"))%>%
  select(starttime,count,Mean_Temperature_F,Events)%>%
  filter( Events %in% c("Rain",""))%>%
  mutate(Rain = ifelse(Events == "", 0,1))

# Calculate first and last date in the dataset for date choice widget
first = min(df.trip$starttime)
last = max(df.trip$stoptime)

############## GLOABL FUNCTINOS ####################################################################################################################

# Function to calculate distances between two geospatial coordinates
hav.dist <- function(long1, lat1, long2, lat2) {
  R <- 6371
  diff.long <- (long2 - long1)
  diff.lat <- (lat2 - lat1)
  a <- sin(diff.lat/2)^2 + cos(lat1) * cos(lat2) * sin(diff.long/2)^2
  b <- 20 * asin(pmin(1, sqrt(a))) 
  d = R * b
  return(d)
}

# Function to add a reset function to the graph
dyUnzoom <-function(dygraph) {
  dyPlugin(
    dygraph = dygraph,
    name = "Unzoom",
    path = system.file("plugins/unzoom.js", package = "dygraphs")
  )
}


# Function to draw crosshair over a graph
dyCrosshair <- function(dygraph, 
                        direction = c("both", "horizontal", "vertical")) {
  dyPlugin(
    dygraph = dygraph,
    name = "Crosshair",
    path = system.file("plugins/crosshair.js", 
                       package = "dygraphs"),
    options = list(direction = match.arg(direction))
  )
}

# Define theme
theme_black = function(base_size = 12, base_family = "") {
  
  theme_grey(base_size = base_size, base_family = base_family) %+replace%
    
    theme(
      # Specify axis options
      axis.line = element_blank(),  
      axis.text.x = element_text(size = base_size*0.8, color = "white", lineheight = 0.9),  
      axis.text.y = element_text(size = base_size*0.8, color = "white", lineheight = 0.9),  
      axis.ticks = element_line(color = "white", size  =  0.2),  
      axis.title.x = element_text(size = base_size, color = "white", margin = margin(0, 10, 0, 0)),  
      axis.title.y = element_text(size = base_size, color = "white", angle = 90, margin = margin(0, 10, 0, 0)),  
      axis.ticks.length = unit(0.3, "lines"),   
      # Specify legend options
      legend.background = element_rect(color = NA, fill = "black"),  
      legend.key = element_rect(color = "white",  fill = "black"),  
      legend.key.size = unit(1.2, "lines"),  
      legend.key.height = NULL,  
      legend.key.width = NULL,      
      legend.text = element_text(size = base_size*0.8, color = "white"),  
      legend.title = element_text(size = base_size*0.8, face = "bold", hjust = 0, color = "white"),  
      legend.position = "right",  
      legend.text.align = NULL,  
      legend.title.align = NULL,  
      legend.direction = "vertical",  
      legend.box = NULL, 
      # Specify panel options
      panel.background = element_rect(fill = "black", color  =  NA),  
      panel.border = element_rect(fill = NA, color = "white"),  
      panel.grid.major = element_line(color = "grey35"),  
      panel.grid.minor = element_line(color = "grey20"),  
      panel.margin = unit(0.5, "lines"),   
      # Specify facetting options
      strip.background = element_rect(fill = "grey30", color = "grey10"),  
      strip.text.x = element_text(size = base_size*0.8, color = "white"),  
      strip.text.y = element_text(size = base_size*0.8, color = "white",angle = -90),  
      # Specify plot options
      plot.background = element_rect(color = "black", fill = "black"),  
      plot.title = element_text(size = base_size*1.2, color = "white"),  
      plot.margin = unit(rep(1, 4), "lines")
      
    )
  
}
